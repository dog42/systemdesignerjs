﻿"use strict";

var codeSymbols = []
//name
//value (or macro)
//tokens[]

function addSymbol(n,m)
{
    //make value into tokens if needed
}

