﻿"use strict";

var errors = [];

function error(parseobj, str)
{
    alert(parseobj.str);
}
