﻿"use strict";

var codeFunctions = []
//name
//returntype (or macro)
//prototypelinenumber
//decllinenumber
//
function addFunction(n, rType, pLine, dLine) {
    //make 
}

